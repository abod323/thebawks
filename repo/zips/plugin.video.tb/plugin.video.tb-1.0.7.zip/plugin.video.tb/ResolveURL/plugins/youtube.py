# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re
from ..utils.browser import Firefox
from ..utils.resolve import Resolver

class Youtube(Resolver):
    def __init__(self):
        self.ytburl = "https://www.youtube.com/channel/{}/live"

    def grab(self, channel):
        firefox = Firefox()
        firefox.addHeader("Alt-Used", "www.youtube.com")
        firefox.addHeader("Cookie", "YSC=xZ55110E6S4; CONSENT=YES+cb.20220320-18-p0.en+FX+712")

        r = requests.get(self.ytburl.format(channel), headers=firefox.headers).content.decode('utf-8')
        pattern = re.compile(r'"hlsManifestUrl":"(.*?)"')
        match = pattern.search(r)
        hlsurl = None
        if match:
            hlsurl = match.group(1)
        return hlsurl, firefox.headers