from urllib.parse import parse_qs
import base64
import requests
import json


def playlist(handler):
    query_string = handler.path.split('?')[1]
    query_params = parse_qs(query_string)

    url = query_params.get("url", [''])[0]
    rw = query_params.get("rw", [''])[0] # Replace with
    o = query_params.get("o", [''])[0] # Text to be replaced

    headersQ = query_params.get("headers", [''])[0]
    headers = json.loads(base64.b64decode(headersQ.encode()).decode())

    if url.startswith("base64:"):
        url = base64.b64decode(url.split("base64:")[1].encode()).decode()
    
    baseURL = url.replace(url.split("/")[-1], "")

    m3u8 = requests.get(url, headers=headers)

    response = []
    for line in m3u8.text.split("\n"):
        if line == "":
            continue


        line = line.replace(".ts", ".js")
        if not line.startswith("#"):
            response.append("/daddylive/chunk.ts?url=" + baseURL + line + f"&headers={headersQ}")

        else:
            response.append(line)
    


    handler.send_header("Content-Type", "application/vnd.apple.mpegurl")
    handler.end_headers()
    return "\n".join(response).replace(o, rw).encode()


def ts(handler):
    query_string = handler.path.split('?')[1]
    query_params = parse_qs(query_string)

    url = query_params.get("url", [''])[0]
    headers = query_params.get("headers", [''])[0]
    headers = json.loads(base64.b64decode(headers.encode()).decode())

    handler.send_header("Content-Type", "video/MP2T")
    handler.end_headers()
    return requests.get(url, headers=headers).content
