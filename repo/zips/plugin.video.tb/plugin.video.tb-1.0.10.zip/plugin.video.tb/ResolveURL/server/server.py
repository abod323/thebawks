from http.server import *
from .routes.daddylive import playlist, ts
from socketserver import ThreadingMixIn



customRoutes = {
    "GET": {
        "/daddylive/playlist.m3u8": playlist,
        "/daddylive/chunk.ts": ts,
    },
    "POST": {}
}


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    pass

class RequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)

        cleanPath = self.path
        if "?" in cleanPath:
            cleanPath = cleanPath.split("?")[0]

        resp = "".encode()
        if cleanPath in customRoutes["GET"]:
            resp = customRoutes["GET"][cleanPath](self)

        self.wfile.write(resp)



def run(port):
    port = ThreadedHTTPServer(('localhost', port), RequestHandler)
    port.serve_forever()