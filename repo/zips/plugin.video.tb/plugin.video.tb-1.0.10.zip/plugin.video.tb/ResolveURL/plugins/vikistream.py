# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

from ..utils.browser import Firefox
from ..utils.resolve import Resolver
import requests
import re

class VikiStream(Resolver):
    def __init__(self):
        self.firefox = Firefox()

    def grab(self, channel):
        self.firefox.addHeader("Referer", "https://1l1l.to/")
        resp = requests.get(f"https://vikistream.com/embed2.php?player=desktop&live={channel}", headers=self.firefox.headers)
        arr = eval(re.findall(r"return\((.*?)\.join\(\"\"\)", resp.text, re.MULTILINE)[0])
        self.firefox.addHeader("Referer", "https://vikistream.com/")
        return "".join(arr).replace("\\/", "/"), self.firefox.headers