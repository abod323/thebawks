# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import re
from ..utils.browser import Firefox
from ..utils.resolve import Resolver
from urllib.parse import urlparse
import json
import base64

class DaddyLive(Resolver):
    def __init__(self):
        pass
    
    def grab(self, channel):
        firefox = Firefox()
        url = f"https://streamservicehd.click/premiumtv/daddyhd.php?id={channel}"
        firefox.addHeader("Referer", "https://daddyhd.com")
        
        attempts = 0
        while attempts <= 3:
            attempts += 1

            resp = requests.get(url, headers=firefox.headers)
            match = re.findall(r"^(?!\/\/)source:\'(.*?)\'", resp.text, re.MULTILINE)
            
            for m in match:
                if "m3u8" in m:
                    firefox.addHeader("Referer", "https://streamservicehd.click/")

                    replaceDomain = requests.get("https://no1.openhd.lol/domain.txt", headers=firefox.headers).text
                    hlsurl = requests.get(m, headers=firefox.headers, allow_redirects=False).headers["location"].replace("index.m3u8", "tracks-v1a1/mono.m3u8")
                    parsed = urlparse(hlsurl)
                    return f"http://127.0.0.1:{self.parent.server_port}/daddylive/playlist.m3u8?url={hlsurl}&rw={replaceDomain}&headers={base64.b64encode(json.dumps(firefox.headers).encode()).decode()}&o={parsed.netloc}", firefox.headers

        return "", {}
            
