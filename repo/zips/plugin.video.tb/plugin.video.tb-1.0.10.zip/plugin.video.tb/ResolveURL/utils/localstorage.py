import json
import os

dp = "./data.json" # default

def checkIfExists(p=dp):
    if not os.path.exists(p): open(p, 'w').write("{}")

def writeToStorage(k, v, p=dp):
    checkIfExists(p)
    loaded = json.loads(open(p, 'r').read())
    loaded[k] = v
    open(p, 'w').write(json.dumps(loaded))

def removeFromStorage(k, p=dp):
    checkIfExists(p)
    loaded = json.loads(open(p, 'r').read())
    if k in loaded:
        del loaded[k]
        open(p, 'w').write(json.dumps(loaded))

def readFromStorage(k, ret="", p=dp):
    checkIfExists(p)
    loaded = json.loads(open(p, 'r').read())
    if k in loaded:
        return loaded[k]
    return ret