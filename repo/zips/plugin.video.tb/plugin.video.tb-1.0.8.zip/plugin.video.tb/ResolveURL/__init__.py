from .utils.resolve import Resolver
from .plugins import *
from .server.server import run

def resolve(module, channel, username="", password="", data_file="./data.json", data_folder="", server_port=8080):
    """
    Args:
        module (str): Plugin to use
        channel (str): Channel to grab
        username (str): Not required, some sources have defaults
        password (str): Not required, some sources have defaults
        data_file (str): Where to store data, default: ./data.json

    Returns:
        rmf (ResolvedMediaFile): use .url or .headers to get data, .test() to test if stream works
    """

    # Filename / Classname in python cannot start with int
    if module[0].isdigit(): module = f"N{module}"

    return Resolver(data_file, data_folder, server_port).resolve(module, channel, username=username, password=password)
    
def server(port=8080):
    """
    Args:
        port (int): Port on which server will be launched
    """
    run(port)