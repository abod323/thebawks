# Credits to madtitansports <3
# Never gonna give you up guys
# Also check 'em out, they do have nice selection of channels

import base64
import requests
from requests.sessions import HTTPAdapter
from ..utils.resolve import Resolver

try:
    from Cryptodome.Cipher import DES, PKCS1_v1_5
    from Cryptodome.Util.Padding import unpad
    from Cryptodome.PublicKey import RSA
    from binascii import a2b_hex
    cryptodomeInstalled = True
except:
    cryptodomeInstalled = False


class UKTVNow(Resolver):
    def __init__(self):
        self.base_url = "https://rocktalk.net/tv/index.php"
        self.player_user_agent = "mediaPlayerhttp/2.5 (Linux;Android 5.1) ExoPlayerLib/2.6.1"
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": "USER-AGENT-tvtap-APP-V2"})
        self.s.mount("https://", HTTPAdapter(max_retries=5))


    def payload(self):
        if cryptodomeInstalled == False: return requests.get("https://AgitatedNervousWearables.npu35322.repl.co/payload").text

        pub_key = RSA.importKey(
            a2b_hex(
                "30819f300d06092a864886f70d010101050003818d003081890281"
                "8100bfa5514aa0550688ffde568fd95ac9130fcdd8825bdecc46f1"
                "8f6c6b440c3685cc52ca03111509e262dba482d80e977a938493ae"
                "aa716818efe41b84e71a0d84cc64ad902e46dbea2ec61071958826"
                "4093e20afc589685c08f2d2ae70310b92c04f9b4c27d79c8b5dbb9"
                "bd8f2003ab6a251d25f40df08b1c1588a4380a1ce8030203010001"
            )
        )
        msg = a2b_hex(
            "7b224d4435223a22695757786f45684237686167747948392b58563052513d3d5c6e222c22534"
            "84131223a2242577761737941713841327678435c2f5450594a74434a4a544a66593d5c6e227d"
        )
        cipher = PKCS1_v1_5.new(pub_key)
        return base64.b64encode(cipher.encrypt(msg))

    def dec(self, enc):
        if cryptodomeInstalled == False: return requests.get(f"https://AgitatedNervousWearables.npu35322.repl.co/dec?enc={enc}").text
        encrypted = base64.b64decode(enc.encode("utf-8")).decode("utf-8")
        d = DES.new(b"98221122", DES.MODE_ECB)
        return unpad(d.decrypt(base64.b64decode(encrypted)), 8).decode("utf-8")

    def apiRequest(self, case, channel_id=None):
        headers = {"app-token": "37a6259cc0c1dae299a7866489dff0bd"}
        data = {"payload": self.payload(), "username": "603803577"}
        if channel_id:
            data["channel_id"] = channel_id
        params = {"case": case}
        r = self.s.post(self.base_url, headers=headers, params=params, data=data, timeout=5)
        r.raise_for_status()
        resp = r.json()
        if resp["success"] == 1:
            return resp["msg"]
        else:
            raise ValueError(resp["msg"])


    def grab(self, pk_id):
        _channel = self.apiRequest("get_channel_link_with_token_latest", pk_id)["channel"][0]
        headers = {"User-Agent": self.player_user_agent}
        links = []
        for stream in _channel.keys():
            if "stream" in stream or "chrome_cast" in stream:
                _crypt_link = _channel[stream]
                if _crypt_link:
                    _crypt_link = base64.b64encode(_crypt_link.encode("utf-8")).decode("utf-8")
                    link = self.dec(_crypt_link)
                    if link.startswith("http"):
                        return link, headers
        raise ValueError("No stream found")