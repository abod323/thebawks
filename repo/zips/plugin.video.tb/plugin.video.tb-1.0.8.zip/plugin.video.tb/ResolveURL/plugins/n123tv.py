# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import base64
import re
from bs4 import BeautifulSoup
from ..utils.browser import Firefox
from ..utils.resolve import Resolver


class N123TV(Resolver):
    def __init__(self):
        self.url = 'http://123tv.live/'

    def __getDecryptionServer(self):
        return 'https://IrritatingSmugEmulator.npu35322.repl.co/'

    def grab(self, channel):
        firefox = Firefox()
        firefox.addHeader("Referer", self.url)
        url = f"{self.url}/watch/{channel}"
        html = requests.get(url, headers=firefox.headers).text

        # 123TV has 2 types of streams
        if ".m3u8?embed=true" in html:
            soup = BeautifulSoup(html, "html.parser")
            iframe = soup.find("iframe", id="123tv-frame")
            hlsurl = requests.get(iframe["src"], headers=firefox.headers).text.split("source:'")[1].split("'")[0]
            firefox.addHeader('Referer', 'http://azureedge.xyz/')
            return hlsurl, firefox.headers
        
        # code is the ["string", "string", ....].join('') part, it is base64 string that contains encrypted data
        code = "['" + html.replace("\n", "").split(".join('')")[0].split("['")[1].split(";")[0]
        code = code.split("['")[1].split("']")[0].replace("','", "")

        # Auth token is required, it is included in html
        jsonauth = "?1&json=" + html.replace('\n', '').split('?1&json=')[1].split("';}")[0]
        

        # "diffs" as I call them, are used to manipulate string in random way before decryption
        diffs = []
        for c in re.findall(r"\[(.*?)\]", html):
            try:
                if c.split(',')[3].isdigit():
                    diffs.append(c)
            except: pass
        diffs = base64.b64encode("|".join(diffs).encode()).decode()

        # Use decryption server to get decrypted link
        r = requests.get(f"{self.__getDecryptionServer()}?json={code}&all={diffs}", headers=firefox.headers).text + jsonauth

        # Get .m3u8 url from decrypted link
        hlsurl = requests.get(r, headers=firefox.headers).text.split('[{"file":"')[1].split('","')[0].replace("\\/", "/")
        return hlsurl, firefox.headers
    