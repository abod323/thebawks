# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

from ..utils.browser import Firefox
from ..utils.resolve import Resolver
import requests
import re

class WikiSport(Resolver):
    def __init__(self):
        self.firefox = Firefox()

    def grab(self, channel):
        self.firefox.addHeader("Referer", "http://streamlivenow.me/")
        resp = requests.get(f"http://wikisport.click/play/{channel}.php", headers=self.firefox.headers)
        src = re.findall(r"<iframe src=\"(.*?)\"", resp.text, re.MULTILINE)[0]

        self.firefox.addHeader("Referer", f"http://wikisport.click/play/{channel}.php")
        resp = requests.get(src, headers=self.firefox.headers)
        fid = re.findall(r"fid=\"(.*?)\";", resp.text, re.MULTILINE)[0]

        self.firefox.addHeader("Referer", "http://wikisport.click/")
        resp = requests.get(f"https://gocast2.com/fsembed.php?player=desktop&live={fid}", headers=self.firefox.headers)
        arr = eval(re.findall(r"return\((.*?)\.join\(\"\"\)", resp.text, re.MULTILINE)[0])

        self.firefox.addHeader("Referer", "https://gocast2.com/")
        return "".join(arr).replace("\\/", "/"), self.firefox.headers
