# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

import requests
import random
from ..utils.browser import Firefox
from ..utils.resolve import Resolver

class USTVGO(Resolver):
    def __init__(self):
        self.proxyServers = requests.get("https://apprehensivedodgerbluecylinders.parrotdevelopers.repl.co/servers").json()


    def grab(self, channel):
        firefox = Firefox()
        firefox.addHeader('Referer', 'http://ustvgo.tv/')
        url = "https://ustvgo.tv/player.php?stream=" + channel
        resp = requests.get(url, headers=firefox.headers)

        if "hls_src" in resp.text:
            return resp.text.replace('\n', '').split("var hls_src='")[1].split("'")[0], firefox.headers
        
        if "Please use the VPN in the link above to access this channel." in resp.text:
            return "", {}

        return f"{random.choice(self.proxyServers)}/grab.php?c={channel}", firefox.headers
        