# -*- coding: utf-8 -*-
# Author: Parrot Developers
# License: MPL 2.0 https://www.mozilla.org/en-US/MPL/2.0/

from ..utils.browser import Firefox
from ..utils.resolve import Resolver
import requests
import re

class Play4You(Resolver):
    def __init__(self):
        self.firefox = Firefox()

    def grab(self, channel):
        self.firefox.addHeader("Referer", f"http://play4you.icu/")
        resp = requests.get(f"http://play4you.icu/e/{channel}", headers=self.firefox.headers)
        embed = re.findall(r".load\('(.*?)\'\+t\)", resp.text, re.MULTILINE)[0]
        embedResp = requests.get(f"http://play4you.icu/{embed}", headers=self.firefox.headers)
        return re.findall(r"var j_churl = '(.*?)'", embedResp.text, re.MULTILINE)[0], self.firefox.headers