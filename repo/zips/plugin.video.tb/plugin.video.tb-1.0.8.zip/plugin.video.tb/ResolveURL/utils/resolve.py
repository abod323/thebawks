from ..utils.rmf import ResolvedMediaFile

class Resolver(object):
    """
    Used for communicating with plugins
    """

    def __init__(self, data_file, data_folder, server_port):
        """
        args:
            data_file (str): Path where to place (where is located) data file
            data_folder (str): Path where addons can store custom data
            server_port (str): Port for locally hosted server
        """
        self.data_file = data_file
        self.data_folder = data_folder
        self.server_port = server_port

    def _getSubclassesNames(self):
        """
        Get names of subclasses

        Use _getSubclasses() to get class objects
        """
        return [cls.__name__ for cls in Resolver.__subclasses__()]

    def _getSubclasses(self):
        """
        Get classes directly
        
        Use _getSubclassesNames() to get only names
        """
        return Resolver.__subclasses__()

    def _getSubclassByName(self, name):
        """
        Get only 1 subclass which matches the name

        returns object
        """

        if name not in self._getSubclassesNames(): return None

        for klass in self._getSubclasses():
            if klass.__name__ == name:
                return klass
        return None

    def resolve(self, module, channel, username="", password=""):
        """
        Args:
            module (str): Plugin to use
            channel (str): Channel to grab
            username (str): Not required, some sources have defaults
            password (str): Not required, some sources have defaults

        Returns:
            rmf (ResolvedMediaFile): use .url or .headers to get data, .test() to test if stream works
        """

        if module.lower() == "swift":
            c = self._getSubclassByName(module)(self.data_folder)
        else:
            c = self._getSubclassByName(module)()
        c.parent = self
        c.username = username
        c.password = password
        hlsurl, headers = c.grab(channel)

        return ResolvedMediaFile(url=hlsurl, headers=headers)

