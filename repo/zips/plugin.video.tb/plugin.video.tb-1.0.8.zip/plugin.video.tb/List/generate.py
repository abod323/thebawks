import json_merge_patch
import json
import os
from collections import OrderedDict



folder = "./src"

folders = [
    #"CS",
    "US",
    "UK",
]
main = {}
for i in folders:
    if os.path.isdir(f"{folder}/{i}"):
        args = "infojson, "
        infojson = OrderedDict(json.load(open(f"{folder}/{i}/info.json", "r")))
        for item in os.listdir(f"{folder}/{i}"):
            if item.endswith(".json") and item != "info.json":
                fn = item.replace('.', '').replace("-", "")
                exec(f"{fn} = OrderedDict(json.loads(open(f'{folder}/{i}/{item}', 'r', encoding='utf-8').read()))")
                args += f"{fn}, "
        main.update(eval(f"json_merge_patch.merge({args})"))
    
stringified = json.dumps(main)
with open(f"./groups.json", "wb") as f:
    #f.write(encrypted)
    f.write(stringified.encode('utf-8'))
