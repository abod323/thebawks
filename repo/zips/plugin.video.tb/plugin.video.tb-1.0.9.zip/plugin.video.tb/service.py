import xbmc
from addon import genPlaylist
from ResolveURL import server
import threading


if __name__ == '__main__':
    monitor = xbmc.Monitor()
    t = threading.Thread(target=server, args=(20555, ))
    t.start()


    while not monitor.abortRequested():
        genPlaylist()
        if monitor.waitForAbort(5 * 60 * 60):
            break

    
