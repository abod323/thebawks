import sys
import os
import xbmcgui
import xbmcplugin
import xbmc
import xbmcaddon
import json as j
import m3u
import resources
import base64
import random
import string
import xbmcvfs
from routing import Plugin
from ResolveURL import resolve
from ResolveURL.utils.browser import Firefox
try: from urllib.parse import urlencode
except ImportError: from urllib import urlencode

pythonVersion = sys.version_info[0]
plugin = Plugin()
_ADDON = xbmcaddon.Addon()
_ID = _ADDON.getAddonInfo('id')
_URL = "plugin://{}".format(_ID)
_PLAYLIST = 'special://home/addons/'+_ID+'/resources/playlist.m3u'
_USERDATA = 'special://home/userdata/addon_data/'+_ID
_ADDON_DIR = "special://home/addons/"+_ID
_ADDON_NAME = _ADDON.getAddonInfo('name')
groupsFile = resources.translatePath(_USERDATA+"/groups.json")

_CUSTOMPLAYLIST_DIR = os.path.join(resources.translatePath(_USERDATA), "CustomPlaylist")
_CUSTOMPLAYLIST_FILE = os.path.join(_CUSTOMPLAYLIST_DIR, "list.json")
if not os.path.exists(_CUSTOMPLAYLIST_DIR): os.makedirs(_CUSTOMPLAYLIST_DIR)
if not os.path.exists(_CUSTOMPLAYLIST_FILE): open(_CUSTOMPLAYLIST_FILE, 'w', encoding="utf-8").write('{}')

def randString(length):
    return ''.join(random.choice(string.ascii_letters) for _ in range(length))

def addDir(name, genre, icon, url, showPlot=True):
    list_item = xbmcgui.ListItem(label=name)
    if showPlot: plot = name
    list_item.setInfo('video', {'title': name,'genre': genre,'plot': plot,'mediatype': 'video'})
    list_item.setArt({'thumb': icon, 'icon': icon})
    xbmcplugin.addDirectoryItem(plugin.handle, url, list_item, True)

def addChannel(name, icon, url, id, showAddToPlaylist=True, removeFromPlaylistID = ""):
    list_item = xbmcgui.ListItem(label=name)
    list_item.setInfo('video', {'title': name,'genre': '','plot': name,'mediatype': 'video'})
    list_item.setArt({'thumb': icon, 'icon': icon})
    if "/play/" in url:
        parts = url.split("/")
        id = parts[4]
        list_item.setProperty('IsPlayable', 'true')
        contextMenuItems = []
        if showAddToPlaylist:
            args = "{}|{}|{}|{}".format(name, icon, url, id)
            args = base64.b64encode(args.encode("utf-8")).decode("utf-8")
            contextMenuItems.append(('Add to custom playlist', 'RunPlugin(plugin://{}/customAdd/{})'.format(_ID, args)))
        if removeFromPlaylistID != "":
            contextMenuItems.append(('Remove from custom playlist', 'RunPlugin(plugin://{}/customRemove/{})'.format(_ID, removeFromPlaylistID)))
        list_item.addContextMenuItems(contextMenuItems)
    xbmcplugin.addDirectoryItem(plugin.handle, url, list_item, False)


def getAllowed():
    allowed = []
    _ADDON = xbmcaddon.Addon()
    if _ADDON.getSettingBool("USEnabled"): allowed.append("US")
    if _ADDON.getSettingBool("UKEnabled"): allowed.append("UK")
    return allowed

def genPlaylist():
    headers = Firefox().headers
    fullList = j.loads(open(resources.translatePath(os.path.join(_ADDON_DIR, "List", "groups.json")), 'r').read())
    allowed = getAllowed()
    m3u = "#EXTM3U\n"
    for ID in fullList:
        item = fullList[ID]

        try:name = item["name"]
        except:
            xbmcgui.Dialog().ok("f", ID)
            continue
         # Use local logo from resources/media folder based on fullList
        logo_filename = item.get("logo", "default_logo.png")  # Fallback to 'default_logo.png' if not found
        logo = resources.translatePath(os.path.join(_ADDON_DIR, "resources", "media", logo_filename))
        country = item["country"]
        tvgid = item["tvg-id"] if "tvg-id" in item else "0"
        url = f"plugin://{_ID}/play/{ID}"

        # Check for geoblock
        if country not in allowed: continue

        # Check if channel is disabled
        if "disabled" in item: 
            if item["disabled"] == True:
                continue

        # Check if there are live sources
        sources = len(item["sources"])
        for src in item["sources"]:
            src = item["sources"][src]
            if "disabled" in src and src["disabled"] == True: sources-=1
        if sources == 0: continue

        m3u += f'#EXTINF:-1 tvg-logo="{logo}" group-title="{country}" tvg-id="{tvgid}" tvg-name="{name}" ,{name}\n{url}\n'

    xbmcaddon.Addon().setSetting("oldGroups", "|".join(allowed))
    open(os.path.join(resources.translatePath(_USERDATA), "channels.json"), 'w', encoding="utf-8").write(j.dumps(fullList))
    open(resources.translatePath(_PLAYLIST), 'w', encoding='utf-8').write(m3u)

if _ADDON.getSetting("updated13") != "true":
    genPlaylist()
    _ADDON.setSetting("updated13", "true") 

def stopifPlaying():
    if xbmc.Player().isPlaying():
        xbmc.Player().stop()

def inpt(title, hidden):
    xbmcplugin.setContent(plugin.handle, 'videos')
    kb = xbmc.Keyboard('', title, hidden)
    kb.doModal()
    query = ""
    if kb.isConfirmed():
        query = kb.getText()
    return query

@plugin.route('/')
def root():
    xbmcplugin.setContent(plugin.handle, 'Home')
    xbmcplugin.setPluginCategory(plugin.handle, "Home")
    if not os.path.exists(resources.translatePath(_PLAYLIST)): genPlaylist(); xbmc.executebuiltin("Container.Refresh")
    if xbmcaddon.Addon().getSetting("oldGroups") != "|".join(getAllowed()): genPlaylist(); xbmc.executebuiltin("Container.Refresh")
    addDir('[COLOR gold]Search[/COLOR]', '', '', "{}/search".format(_URL), True)
    addDir('[COLOR gold]Channels[/COLOR]', '', '', "{}/channels".format(_URL), True)
    addDir('[COLOR gold]Countries[/COLOR]', '', '', "{}/categories".format(_URL), True)
    addDir('[COLOR gold]Custom Playlist[/COLOR]', '', '', "{}/custom".format(_URL), True)
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/search')
def search():
    xbmcplugin.setContent(plugin.handle, 'Search')
    xbmcplugin.setPluginCategory(plugin.handle, "Search")
    query = inpt("Enter search query:", False)
    if query:
        names, logos, urls, groups, ids = m3u.parse("names,logos,urls,groups,ids")
        for name, logo, url, group, id in zip(names, logos, urls, groups, ids):
            if query.lower() in name.lower():
                addChannel(f"[COLOR gold]{group}: {name}[/COLOR]", logo, url, id)
        xbmcplugin.endOfDirectory(plugin.handle)
    else:
        xbmcgui.Dialog().ok(_ADDON_NAME, 'No search query entered.')
        exit()

@plugin.route('/channels')
def channels():
    xbmcplugin.setContent(plugin.handle, 'Channels')
    xbmcplugin.setPluginCategory(plugin.handle, "Channels")
    names, logos, urls, ids = m3u.parse("names,logos,urls,ids")
    for name, logo, url, id in zip(names, logos, urls, ids):
        addChannel(f"[COLOR gold]{name}[/COLOR]", logo, url, id)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/categories/')
def categories():
    xbmcplugin.setContent(plugin.handle, 'Countries')
    xbmcplugin.setPluginCategory(plugin.handle, "Countries")
    groups = m3u.parse("groups")
    # remove duplicates
    groups = list(set(groups))
    for group in groups:
        img = f"https://flagpedia.net/data/flags/w640/{group.lower() if group.lower() != 'uk' else 'gb'}.webp"
        addDir('[COLOR gold]{}[/COLOR]'.format(group), '', img, "{}/category/{}".format(_URL, group), True)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/category/<category>')
def category(category):
    xbmcplugin.setContent(plugin.handle, 'Countries')
    xbmcplugin.setPluginCategory(plugin.handle, "Countries")
    names, logos, urls, groups, ids = m3u.parse("names,logos,urls,groups,ids")
    for name, logo, url, group, id in zip(names, logos, urls, groups, ids):
        if group == category:
            addChannel(f"[COLOR gold]{name}[/COLOR]", logo, url, id)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/play/<id>')
def play(id):
    # Load channels data from JSON
    channels = j.loads(open(os.path.join(resources.translatePath(_USERDATA), "channels.json"), 'r', encoding='utf-8').read())

    # Initialize lists to store available sources
    names = []
    modules, chs = [], []
    
    # Iterate over sources and store their details if they are not disabled
    for key, value in channels[id]["sources"].items():
        if not value.get("disabled", False):
            names.append(value["name"])
            modules.append(value["module"])
            chs.append(value["channel"])

    # Check if any sources are available
    if len(names) == 0:
        xbmcgui.Dialog().ok("Error", "No available sources")
        return

    # Try to auto-select "uktvnow" source (case-insensitive)
    select = 0  # Default to first source
    lower_names = [name.lower() for name in names]  # Convert names to lowercase for case-insensitive comparison
    if "uktvnow" in lower_names:
        select = lower_names.index("uktvnow")  # Auto-select "uktvnow" if available (case-insensitive)
    else:
        xbmcgui.Dialog().notification("Info", "UKTVNow source not found, using the first available source.")

    # Retrieve the module and stream for the selected source
    module, stream = modules[select], chs[select]

    # Ensure ResolveURL data folder exists
    os.makedirs(xbmcvfs.translatePath(_USERDATA + "/ResolveURL_data"), exist_ok=True)

    # Handle specific case for module names
    if module == "123TV":
        module = "N123TV"

    # Resolve the stream URL
    rmf = resolve(
        module=module,
        channel=stream,
        data_folder=xbmcvfs.translatePath(_USERDATA + "/ResolveURL_data"),
        data_file=xbmcvfs.translatePath(_USERDATA + "/ResolveURL_data.json"),
        server_port=20555
    )
    
    # Get the resolved HLS URL and headers
    hlsurl, headers = rmf.url, rmf.headers

    # Play the resolved stream URL
    li = xbmcgui.ListItem(path=hlsurl + '|' + urlencode(headers))
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(plugin.handle, True, li)


@plugin.route('/custom')
def custom():
    xbmcplugin.setContent(plugin.handle, 'Custom Playlist')
    xbmcplugin.setPluginCategory(plugin.handle, "Custom Playlist")
    customList = open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'r', encoding='utf-8').read()
    if customList == "{}":
        xbmcgui.Dialog().ok(_ADDON_NAME, 'No channels added to custom playlist.')
        exit()
    customList = j.loads(customList)
    for item in customList:
        name = customList[item]["name"]
        logo = customList[item]["logo"]
        url = customList[item]["url"]
        id = customList[item]["id"]
        addChannel(f"[COLOR gold]{name}[/COLOR]", logo, url, id, showAddToPlaylist=False, removeFromPlaylistID=item)
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/customAdd/<args>')
def customAdd(args):
    args = base64.b64decode(args).decode("utf-8")
    args = args.split("|")
    customList = open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'r', encoding='utf-8').read()
    customList = j.loads(customList)
    customList.update({randString(30): {"name": args[0], "logo":args[1], "url": args[2], "id": args[3]}})
    open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'w', encoding='utf-8').write(j.dumps(customList))
    xbmcgui.Dialog().ok(_ADDON_NAME, 'Channel added to custom playlist.')
    xbmc.executebuiltin("Container.Refresh")

@plugin.route('/customRemove/<id>')
def customRemove(id):
    customList = open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'r', encoding='utf-8').read()
    customList = j.loads(customList)
    del customList[id]
    open(resources.translatePath(_CUSTOMPLAYLIST_FILE), 'w', encoding='utf-8').write(j.dumps(customList))
    xbmcgui.Dialog().ok(_ADDON_NAME, 'Channel removed from custom playlist.')
    xbmc.executebuiltin("Container.Refresh")


@plugin.route('/ISS')
def iptvsimpleSetup():
    try:pisc = xbmcaddon.Addon('pvr.iptvsimple')
    except:
        xbmcgui.Dialog().notification(_ADDON_NAME, "IPTV Simple not found", xbmcgui.NOTIFICATION_INFO, 5000)
        return
    pisc.setSetting('m3uPathType','0')
    pisc.setSetting('m3uPath', resources.translatePath(_PLAYLIST))
    pisc.setSetting('m3uRefreshMode','1')
    pisc.setSetting('m3uRefreshIntervalMins','30')
    pisc.setSetting('startNum','1')
    xbmcgui.Dialog().notification(_ADDON_NAME, "IPTV Simple setup completed", xbmcgui.NOTIFICATION_INFO, 5000)


if __name__ == "__main__":
    stopifPlaying()
    plugin.run(sys.argv)
    