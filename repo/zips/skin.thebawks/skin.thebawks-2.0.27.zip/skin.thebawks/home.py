import xbmc
import xbmcgui

def showDialog():
    dialog = xbmcgui.Dialog()
    dialog.ok('Hello', 'Hello World!')